#pragma once
#include<iostream>

class Photo {
public:
	Photo() = default;
	virtual ~Photo() = default;
	Photo(int l, int w) :length(l), width(w) {}
	virtual void show()const {
		std::cout << "Length:" << length << std::endl;
		std::cout << "width:" << width << std::endl << std::endl;
	}
protected:
	int length;//ͼƬ�ĳ�
	int width;//ͼƬ�Ŀ�
};

class Gif :public Photo {
public:
	Gif() = default;
};

class Tiff :public Photo {
public:
	Tiff() = default;
};

class Jpeg :public Photo {
public:
	Jpeg() = default;
};

class Bmp :public Photo {
public:
	Bmp() = default;
};