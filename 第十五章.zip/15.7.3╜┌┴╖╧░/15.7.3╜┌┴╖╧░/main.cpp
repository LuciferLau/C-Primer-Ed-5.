#include"QUOTE.h"
#include<vector>
#include<memory>
using namespace std;

void f1() {//��������
	Bulk_Quote a("�����鱾", 100, 50, 0.75);
	Bulk_Quote b(a);
	cout << endl;
	Bulk_Quote c = b;
	cout << endl;
	a.debug();
	b.debug();
	c.debug();
}

void f2() {
	Quote a("�����ġ�", 100);
	Bulk_Quote b("��Ӣ�", 100, 50, 0.75);
	auto pa = make_shared<Quote>(a);
	auto pb = make_shared<Bulk_Quote>(b);
	vector<shared_ptr<Quote>>vec;
	vec.push_back(pa);
	vec.push_back(pb);
	for (auto v : vec) 
		cout << v->isbn()<<"100���ۼ��ǣ�" << v->net_price(100) << endl;
}

int main(char argc, char **argv) {
	f2();
	system("pause");
	return 0;
}