#include"BASKET.h"

using namespace std;

int main()
{
	Quote a("�����ġ�", 100);
	Bulk_Quote b ("����ѧ��", 100,50,0.75);
	Bulk_Quote c("��Ӣ�", 100,50,0.5);
	Basket bucket;
	bucket.add_item(a);
	for (auto i = 0; i < 100; ++i) {
		bucket.add_item(b);
		bucket.add_item(c);
	}
	bucket.total_price();
	system("pause");
}