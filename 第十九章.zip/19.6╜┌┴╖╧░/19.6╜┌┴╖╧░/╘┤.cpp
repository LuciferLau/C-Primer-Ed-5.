#include"��ͷ.h"

using namespace std;

void fcn() {
	Token a;
	cout << a << endl << endl;
	a = 1;
	cout << a << endl << endl;
	a = 'a';
	cout << a << endl << endl;
	a = 123.456;
	cout << a << endl << endl;
	a = "I'm a string !";
	cout << a << endl << endl;
	a = a;
	cout << a << endl << endl;
	a = std::move(a);
	cout << a << endl << endl;
}

int main()
{
	fcn();
	cin.get();
	return 0;
}