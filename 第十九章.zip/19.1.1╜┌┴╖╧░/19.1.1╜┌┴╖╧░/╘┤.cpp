#include<iostream>

using namespace std;

void* operator new(size_t size) {
	cout << "my new!" << endl;
	if (void *mem = malloc(size))
		return mem;
	else
		throw bad_alloc();
}

void operator delete(void* p) noexcept {
	cout << "my delete!" << endl;
	free(p);
}

int main()
{
	int *a = new int(123);
	cout << a << ": " << *a << endl;
	delete a;
	cin.get();
}