#include<iostream>

using namespace std;

class A {
public:
	A()=default;
	virtual ~A() {}
};

class B :public A {
public:
	B() = default;
	~B() {}
};

class C :public B {
public:
	C() = default;
	~C() {}
};

int main()
{
	A *pa = new C;
	cout << typeid(pa).name() << endl;
	cout << typeid(*pa).name() << endl;

	C cobj;
	A &ra = cobj;
	cout << typeid(ra).name() << endl;
	cout << typeid(&ra).name() << endl;

	B *px = new B;
	A &rb = *px;
	cout << typeid(rb).name() << endl;
	cout << typeid(&rb).name() << endl;

	cin.get();
}