#include<iostream>
#include<utility>
#include<string>
#include<vector>

using namespace std;

void f1112() {
	string a;
	int b;
	pair<string, int>pp;
	vector<pair<string, int>>vec;
	while (cin >> a, cin >> b) {
		pp.first = a;
		pp.second = b;
		vec.push_back(pp);
	}
	for (const auto v : vec)
		cout << v.first << " " << v.second << endl;
}

void f1113() {
	string a;
	int b;
	pair<string, int>pp;
	vector<pair<string, int>>vec;
	while (cin >> a, cin >> b) {
		//����1��
		pp.first = a;
		pp.second = b;
		//����2��
		//pp={a,b};
		//����3��
		//pp=make_pair(a, b);
		vec.push_back(pp);
	}
	for (const auto v : vec)
		cout << v.first << " " << v.second << endl;
}
int main()
{
	f1113();
	system("pause");
}