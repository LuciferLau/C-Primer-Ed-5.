#pragma once
#include<iostream>
#include<string>
#include<vector>

class HasPtr {
public:
	friend void vec_print(const std::vector<HasPtr> &);
	friend bool operator<(const HasPtr &h1, const HasPtr &h2);
	friend void swap(HasPtr&, HasPtr&);
	friend void print(const HasPtr&);
	HasPtr(const std::string &s = std::string()) :ps(new std::string(s)), i(0) {}
	HasPtr(const HasPtr &hp) : ps(new std::string(*hp.ps)), i(hp.i) {}
	//HasPtr& operator=(const HasPtr &hp) { ps = hp.ps; i = hp.i; return *this; }�ҵľɰ汾
	HasPtr& operator=(const HasPtr &);
	~HasPtr() { delete ps; }
private:
	std::string * ps;
	int i;
};

HasPtr& HasPtr::operator=(const HasPtr &hp) {//�����°汾
	auto newp = new std::string(*hp.ps);//�����ײ�string
	delete ps;//�ͷž��ڴ�
	ps = newp;
	i = hp.i;
	return *this;
}

inline bool operator<(const HasPtr &h1, const HasPtr &h2) {
	if ((*h1.ps).size() > (*h2.ps).size())//��������
		return false;
	else if ((*h1.ps).size() == (*h2.ps).size())//�ֵ�����
		return *h1.ps < *h2.ps;
	else 
		return true;
}

inline void swap(HasPtr&h1, HasPtr&h2) {
	using std::swap;
	swap(h1.ps, h2.ps);
	swap(h1.i, h2.i);
	std::cout << "������ɣ�" << std::endl;
}

inline void print(const HasPtr&hp) {
	std::cout << "i�ǣ�" << hp.i << std::endl;
	std::cout << "ps�ǣ�" << *hp.ps << std::endl;
	std::cout << "ps��ַ�ǣ�" << hp.ps << std::endl;
	std::cout << std::endl;
}

inline void vec_print(const std::vector<HasPtr> &v){
	int number = 0;
	for (auto it = v.cbegin(); it != v.cend(); ++it)
		std::cout << "��" << number++ << "���ַ����ǣ�" << *(it->ps) << std::endl;
}