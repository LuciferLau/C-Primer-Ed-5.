#pragma once
#include"TREENODE.h"

class BinStrTree {
	BinStrTree():root(new TreeNode()){}
	BinStrTree(const BinStrTree &bst) :root(new TreeNode(*bst.root)) {}
	BinStrTree& operator=(const BinStrTree &bst){
		auto newp = new TreeNode(*bst.root);
		delete root;
		root = newp;
		return *this;
	}
	~BinStrTree() { delete root; }
private:
	TreeNode * root;
};