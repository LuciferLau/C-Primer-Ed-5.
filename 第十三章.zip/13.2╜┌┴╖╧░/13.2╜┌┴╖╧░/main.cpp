#include"HASPTR.h"
#include<vector>
#include<algorithm>
using namespace std;


int main()
{
	vector<HasPtr>vec;
	string s1 = "just for test.", s2 = "A little longer one.", s3 = "kust for test.";
	HasPtr h1(s1), h2(s2), h3(s3);
	vec.push_back(h3);
	vec.push_back(h2);
	vec.push_back(h1);
	vec_print(vec);
	sort(vec.begin(), vec.end());
	vec_print(vec);
	system("pause");
}