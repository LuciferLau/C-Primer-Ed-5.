#pragma once
#include<iostream>
#include<string>

class TreeNode {
public:
	TreeNode() :value(std::string()), count(0), left(nullptr), right(nullptr) {}
	TreeNode(const TreeNode &t) :value(t.value), count(t.count), left(t.left), right(t.right) { ++count; }
	TreeNode& operator=(const TreeNode &t) {
		value = t.value;
		count = t.count;
		left = t.left;
		right = t.right;
		return *this;
	}
	~TreeNode() { delete left; delete right; }
private:
	std::string value;
	int count;
	TreeNode *left;
	TreeNode *right;
};