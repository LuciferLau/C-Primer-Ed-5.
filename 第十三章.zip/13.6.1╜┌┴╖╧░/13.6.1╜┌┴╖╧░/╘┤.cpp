#include"str.h"
#include<vector>

using namespace std;

int main()
{
	vector<String>vec;
	String s1 = "leo";
	String s2, s3;
	s2 = s1;
	vec.push_back(s1);
	vec.push_back(s2);
	vec.push_back(s3);
	vec.push_back(s3);
	system("pause");
}