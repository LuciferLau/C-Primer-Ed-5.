#pragma once
#include<iostream>
#include<set>
#include<string>

class Folder;

class  Message
{
	friend class Folder;
public:
	explicit Message(const std::string &s = "") :contents(s) {}//Ĭ�Ϲ��캯��������������explicit���η�ֹ��ʽת��
	Message(const Message &m) :contents(m.contents), fset(m.fset) { add_to_Folders(m); }//�������캯��
	Message& operator=(const Message&);//������ֵ�����
	~Message() { remove_from_Folders(); }//��������
	void save(Folder &);
	void remove(Folder&);
	friend void swap(Message &, Message &);
private:
	std::string contents;
	std::set<Folder*>fset;
	void add_to_Folders(const Message &);
	void remove_from_Folders();
};

void Message::save(Folder &f) {
	fset.insert(&f);
	f.addMsg(this);
}

void Message::remove(Folder &f) {
	fset.erase(&f);
	f.remMsg(this);
}

void Message::add_to_Folders(const Message &m) {
	for (auto f : m.fset)
		f->addMsg(this);
}

Message::Message(const Message &m) :
	contents(m.contents), fset(m.fset) {
	add_to_Folders(m);
}

void Message::remove_from_Folders() {
	for (auto f : fset)
		f->remMsg(this);
}

Message& Message::operator=(const Message &yz) {
	remove_from_Folders();
	contents = yz.contents;
	fset = yz.fset;
	add_to_Folders(yz);
	return *this;
}

void swap(Message &left, Message &right) {
	using std::swap;
	for (auto f : left.fset)
		f->remMsg(&left);
	for (auto f : right.fset)
		f->remMsg(&right);
	swap(left.fset, right.fset);
	swap(left.contents, right.contents);
	for (auto f : left.fset)
		f->addMsg(&left);
	for (auto f : right.fset)
		f->addMsg(&right);
}

class Folder
{
public:
	Folder() {}
	~Folder() {}
	Folder(const Folder &);
	Folder& operator=(const Folder &);
	void addMsg(Message *m) { mset.insert(m); }
	void remMsg(Message *m) { mset.erase(m); }
private:
	set<Message*>mset;
};



