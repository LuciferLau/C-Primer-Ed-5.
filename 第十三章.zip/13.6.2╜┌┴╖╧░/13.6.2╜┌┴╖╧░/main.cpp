#include"String.h"
#include<vector>

using namespace std;

int main()
{
	vector<String>vec;
	String s1("halo");
	cout << endl;
	String s2 = s1;
	cout << endl;
	String s3 = std::move(s1);
	cout << endl;
	String s4(s3);
	cout << endl << "ѹ��s1��" << endl;
	vec.push_back(s1);
	cout << endl << "ѹ��s2��" << endl;
	vec.push_back(s2);
	cout << endl << "ѹ��s3��" << endl;
	vec.push_back(s3);
	cout << endl << "ѹ��s4��" << endl;
	vec.push_back(s4);
	system("pause");
}