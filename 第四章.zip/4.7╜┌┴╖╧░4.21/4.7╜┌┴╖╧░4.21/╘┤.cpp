#include<iostream>
#include<vector>

using namespace std;

int main() {
	vector<int>vec{ 1,2,3,4,5,6,7,8 };
	for (auto &v : vec) {
		v % 2 == 1 ? v *= 2 : v;//��������� ? :
		cout << v << " ";
	}
	cout << endl;
	cin.get();
	return 0;
}