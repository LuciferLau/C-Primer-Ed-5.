#include<iostream>
using namespace std;

int main()
{
	cout << 30 / 3 * 21 % 5 << endl<<
		- 30 / 3 * 21 % 4<<endl;
	cin.get();
	return 0;
}