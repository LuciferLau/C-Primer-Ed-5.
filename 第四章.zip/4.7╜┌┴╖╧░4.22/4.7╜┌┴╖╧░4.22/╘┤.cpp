#include<iostream>
#include<string>

using namespace std;

void ver1(int grade[]) {
	cout << "verion ?:" << endl;
	string finalgrade = {};
	for (int i = 0; i < 5; ++i) {
		finalgrade = (grade[i] < 60) ? "fail!" :
			(grade[i] < 75) ? "low pass!" :
			(grade[i] < 90) ? "pass!" : "high pass!";
		cout << finalgrade << endl;
	}
}

void ver2(int grade[]) {
	cout << "verion if" << endl;
	string finalgrade = {};
	for (int i = 0; i < 5; ++i) {
		if (grade[i] < 60)
			finalgrade = "fail!";
		else if (grade[i] < 75)
			finalgrade = "low pass!";
		else if (grade[i] < 90)
			finalgrade = "pass!";
		else finalgrade = "high pass!";
		cout << finalgrade << endl;
	}
}

int main() {
	int grade[5] = {60,70,80,90,10};
	ver1(grade);
	cout << endl;
	ver2(grade);
	cin.get();
	return 0;
}