#include<iostream>
#include<vector>
#include<memory>
#include<new>
using namespace std;

void getint(vector<int>*&p) {
	int num;
	while (cin >> num)
		p->push_back(num);
	cout << "������ɣ�" << endl;
}

void print(vector<int>*&pvec) {
	cout << "vector: ";
	for (const auto v : *pvec)
		cout << v << ends;
	cout << endl;
}

void getint(shared_ptr<vector<int>>&vec) {
	int num;
	while (cin >> num)
		vec->push_back(num);
	cout << "������ɣ�" << endl;
}

void print(shared_ptr<vector<int>>&vec) {
	cout << "vector: ";
	for (const auto v : *vec)
		cout << v << ends;
	cout << endl;
}

int main()
{
	/*vector<int>*pvec = new vector<int>;//��ϰ12.6
	getint(pvec);
	print(pvec);
	delete pvec;*/
	shared_ptr<vector<int>>vec = make_shared<vector<int>>();//��ϰ12.7
	getint(vec);
	print(vec);
	system("pause");
}