#include<iostream>
#include<memory>

using namespace std;

struct destination {};
struct connection {};
connection connect(destination) {};

void disconnect(connection *c) {};

void end_connection(connection *c) {
	disconnect(c);
}

void f(destination &d) {
	connection c = connect(d);
	shared_ptr<connection>p(&c,end_connection);//��������ָ�뱣֤�ͷ�c������ͷ�
}

void f(destination &d) {
	connection c = connect(d);
	shared_ptr<connection>p(&c, [](connection *c) {	disconnect(c); });//ʹ��lambda
}

int main()
{
	

}