#include<iostream>
#include<memory>
#include<string>
using namespace std;

void f1223() {
	string s1("aosigh");
	string s2("231234");
	string str = s1 + s2;
	size_t big = str.size();
	char *sz = new char[big];//��̬�����顱
	for (size_t i = 0; i != big; ++sz, ++i) {
		*sz = str[i];
		cout << *sz;
	}
	delete[]sz;
}

void f1224() {
	string s;
	cout << "�������ַ�����"; cin >> s;
	char *sz = new char[1];//��̬�����顱
	for (size_t i = 0; i != s.size(); ++sz, ++i) {
		*sz = s[i];
	}
	cout << sz;
	delete[]sz;
}

int main()
{
	f1224();
	system("pause");
}