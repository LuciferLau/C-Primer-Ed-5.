#include<iostream>
#include<string>
#include<memory>

using namespace std;

void func() {
	allocator<string>alloc;
	size_t n;
	cout << "������Ҫ����Ĵ�С��"; cin >> n;
	auto const p = alloc.allocate(n);
	string str;
	string *q = p;
	while (cin >> str && q != p + n)
		alloc.construct(q++, str);
	cout << endl << "������ַ���Ϊ��" << endl;
	for (auto it = p; it != q; ++it) 
		cout << *it << endl;
	const size_t big = q - p;
	cout << "���ô�СΪ��" << big << endl;
	while (q != p)
		alloc.destroy(--q);
	alloc.deallocate(p, n);
}

int main()
{
	func();
	system("pause");
	return 0;
}