#pragma once
#include<iostream>
#include<string>
#include<vector>
#include<map>
#include<set>
#include<memory>
#include<fstream>
#include<sstream>
using namespace std;

class QueryResult;

class TextQuery {
public:
	TextQuery() = default;
	TextQuery(ifstream&);
	using line_no = vector<string>::size_type;
	QueryResult query(const string&)const;
private:
	shared_ptr<vector<string>>file;
	map<string, shared_ptr<set<line_no>>>wm;
};

class QueryResult {
	friend ostream& print(ostream &, const QueryResult &);
	using line_no = vector<string>::size_type;
public:
	QueryResult(string s, shared_ptr<set<line_no>>p, shared_ptr<vector<string>>f) :sought(s), lines(p), file(f) {}
private:
	string sought;
	shared_ptr<set<line_no>> lines;
	shared_ptr<vector<string>>file;
};

