#include<iostream>
#include<string>

using namespace std;

int main() {
	unsigned aCnt = 0, eCnt = 0, iCnt = 0, oCnt = 0, uCnt = 0;
	unsigned spaceCnt = 0, symCnt = 0, nCnt = 0;
	unsigned ffCnt = 0, flCnt = 0, fiCnt = 0;
	
	char ch;
	char char_before = '/0';
	cout << "�������ַ�����";
	while (cin >> std::noskipws >> ch) {//std::noskipws���ڱ�֤�ո�ͻ��з�����ȡ
		switch (ch) {
			
		case'a':
		case'A':
			++aCnt;
			break;
		case'e':
		case'E':
			++eCnt;
			break;
		case'i':
			if (char_before == 'f')
				++fiCnt;
		case'I':			
			++iCnt;
			break;
		case'o':
		case'O':
			++oCnt;
			break;
		case'u':
		case'U':
			++uCnt;
			break;
		case'\n':
			++nCnt;
			break;
		case 'f':
			if (char_before == 'f')			
				++ffCnt;
			break;
		case 'l':
			if (char_before == 'f')			
				++flCnt;			
			break;
		default:
			if (ispunct(ch))
				++symCnt;
			if (isspace(ch))
				++spaceCnt;
			break;
		}
		char_before = ch;
	}
	cout << ch << endl;
	cout << "Ԫ����ĸ��" << endl;
	cout << "A/a : " << aCnt << endl;
	cout << "E/e : " << eCnt << endl;
	cout << "I/i : " << iCnt << endl;
	cout << "O/o : " << oCnt << endl;
	cout << "U/u : " << uCnt << endl;
	cout << endl << "�������ţ�" << endl;
	cout << "���з���" << nCnt << endl;
	cout << "�ո�" << spaceCnt << endl;
	cout << "�Ʊ�����" << symCnt << endl;
	cout << endl << "������ϣ�" << endl;
	cout << "ff : " << ffCnt << endl;
	cout << "fl : " << flCnt << endl;
	cout << "fi : " << fiCnt << endl << endl;
	system("pause");
	return 0;
}