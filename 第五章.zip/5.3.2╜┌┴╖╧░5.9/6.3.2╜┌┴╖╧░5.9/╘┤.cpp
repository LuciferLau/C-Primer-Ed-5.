#include<iostream>
#include<string>
using namespace std;

int main() {
	string text;
	int res = 0;
	while (cin >> text) {
		for (auto s : text) {
			switch (s)
			{
			case 'a':case 'e':case 'i':case 'o':case 'u':case 'A':case 'E':case 'I':case 'O':case 'U':
				++res;
				break;
			default:
				break;
			}
		}
	}
	cout << "һ���У�" << res << " ��Ԫ����ĸ." << endl;
	system("pause");
	return 0;
}