#include<iostream>
#include<string>

using namespace std;

int main()
{
	string str, before_str = "";
	bool status = false;
	while (cin >> str){
		if (str == before_str) {
			if (str[0] > 'A'&&str[0] < 'Z') {
				cout << str << " repeat 2 times!" << endl;
				status = true;
				break;
			}
			else continue;
		}
		before_str = str;
	}
	if (status == false) cout << "no repeat!" << endl;
	system("pause");
	return 0;
}