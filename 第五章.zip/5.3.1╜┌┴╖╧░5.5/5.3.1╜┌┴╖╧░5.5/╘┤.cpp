#include<iostream>
#include<vector>
#include<string>
#include<cctype>
using namespace std;

void ifelsegetgrade(const vector<string>&grade) {//ʹ��if else
	int score = 0;
a:	cout << "please input your score : ";
	cin >> score;
	if (!(score<100 && score>0)) {
		cerr << "Wrong input !" << cin.fail() << endl;
		system("pause");
		system("cls");
		goto a;
	}
	cout << "Your grade is : ";
	if (score < 60)//������
		cout << grade[0] << endl;
	else {//����
		if ((score % 10) > 7) {	//��+��
			string res = grade[(score - 50) / 10] + "+";
			cout << res << endl;
		}
		else if ((score % 10) < 3) {//��-��
			string res = grade[(score - 50) / 10] + "-";
			cout << res << endl;
		}
		else//��û��
			cout << grade[(score - 50) / 10] << endl;
	}
}

void wenhaogetgrade(const vector<string>&grade) {//ʹ����������� ? :
	int score = 0;
a:	cout << "please input your score : ";
	cin >> score;
	if (!(score<100 && score>0)) {
		cerr << "Wrong input !" << cin.fail() << endl;
		system("pause");
		system("cls");
		goto a;
	}
	cout << "Your grade is : ";
	string res = score < 60 ? (grade[0]) :
		((score % 10) > 7) ?
		(grade[(score - 50) / 10] + "+") :
		((score % 10) < 3) ?
		(grade[(score - 50) / 10] + "-") :
		grade[(score - 50) / 10];
	cout << res << endl;
}

int main() {
	const vector<string>grade{ "F","D","C","B","A","S" };
	ifelsegetgrade(grade);
	wenhaogetgrade(grade);
	system("pause");
	return 0;
}