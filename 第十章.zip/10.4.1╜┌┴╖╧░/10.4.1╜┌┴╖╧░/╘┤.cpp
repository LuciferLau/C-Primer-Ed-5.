#include<iostream>
#include<vector>
#include<list>
#include<deque>
#include<algorithm>
#include<iterator>
#include<functional>

using namespace std;

void f1027() {
	vector<int>vec{ 1,1,4,5,6,7,1,1,2,3,4 };
	list<int>ll;
	ll.resize(vec.size());
	sort(vec.begin(), vec.end());
	unique_copy(vec.begin(), vec.end(), ll.begin());
	for (auto l : ll)
		if (l != 0)
			cout << l << ends;
	cout << endl;
}

void print(list<int>&lst) {
	for (auto l : lst)
		cout << l << ends;
	cout << endl;
}

void f1028() {
	vector<int>vec{ 1,2,3,4,5,6,7,8,9 };
	list<int>lst1;//back_inserter
	list<int>lst2;//front_inserter
	list<int>lst3;//inserter
	auto l1 = back_inserter(lst1);
	auto l2 = front_inserter(lst2);
	auto l3 = inserter(lst3, lst3.begin());
	copy(vec.cbegin(), vec.cend(), l1);
	copy(vec.cbegin(), vec.cend(), l2);
	copy(vec.cbegin(), vec.cend(), l3);
	cout << "lst1 : "; print(lst1);
	cout << "lst2 : "; print(lst2);
	cout << "lst3 : "; print(lst3);
}

int main()
{
	f1028();
	system("pause");
}