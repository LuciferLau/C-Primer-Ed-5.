#include<iostream>
#include<algorithm>
#include<vector>
#include<string>

using namespace std;

void elimDups(vector<string>&vec) {
	sort(vec.begin(), vec.end());
	auto end_it = unique(vec.begin(), vec.end());
	vec.erase(end_it, vec.cend());
}

inline bool isShorter(const string &s1, const string &s2) {
	return s1.size() < s2.size();
}

void print(vector<string>&vec) {
	cout << "vector has: ";
	for (const auto v : vec)
		cout << v << ends;
	cout << endl;
}

inline bool highfive(const string &s) {
	return s.size() > 5;
}

inline string make_plural(const string &word, const string &ending, size_t ctr) {
	return (ctr > 1) ? word + ending : word;
}

void biggies(vector<string>&vec, vector<string>::size_type sz) {
	elimDups(vec);
	stable_sort(vec.begin(), vec.end(), [](const string &a, const string &b) {return a.size() < b.size(); });
	auto wc = find_if(vec.begin(), vec.end(), [sz](const string &s) {return s.size() >= sz; });//void bigger()��partition����find_if
	auto count = vec.cend() - wc;
	cout << count << " " << make_plural("word", "s", count) << " �ĳ��ȴ��ڵ��� " << sz << endl;
	for_each(wc, vec.end(), [](const string &s) {cout << s << ends; });
	cout << endl;
}

void bigger(vector<string>&vec, vector<string>::size_type sz) {
	elimDups(vec);
	stable_sort(vec.begin(), vec.end(), [](const string &a, const string &b) {return a.size() < b.size(); });
	auto wc = stable_partition(vec.begin(), vec.end(), [sz](const string &s) {return s.size() >= sz; });//��partition����find_if
	auto count = vec.cend() - wc;
	cout << count << " " << make_plural("word", "s", count) << " �ĳ��ȴ��ڵ��� " << sz << endl;
	for_each(wc, vec.end(), [](const string &s) {cout << s << ends; });
	cout << endl;
}

int main()
{
	//��ϰ10.14
	[](const int &a, const int &b) {return a + b; };//lambda����������int���������ǵĺ�
	//��ϰ10.15
	int num = 0;
	[num](const int a = 10) {cout << a + num; };
	//��ϰ10.16
	vector<string>words{ "cemetery","several","location","ask","remove","just" };
	print(words);
	biggies(words, 5);
	//��ϰ10.18||10.19
	cout << endl;
	vector<string>word{ "cemetery","cemeterx","cemeterz","several","location","ask","remove","just" };
	print(word);
	biggies(word, 5);
	system("pause");
}