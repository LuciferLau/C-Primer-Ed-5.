#include<vector>
#include<algorithm>
#include<iostream>
#include<string>

using namespace std;

void func() {
	int num = 5;
	auto f = [num]()mutable->bool {//β������bool
		if (num == 0) 
			return true;
		else {
			--num;
			return false;
		}
	};
	int j = f();
	cout << j << endl;
}

int main()
{
	vector<string>vec{ "for","example","we","are","the","best","people" };
	cout << "vector���� " << count_if(vec.cbegin(), vec.cend(), [](const string &s) {return s.size() > 6; }) << "�����ȴ���6�ĵ��ʡ�" << endl;//10.20
	func();//10.21
	system("pause");
}