#include<iostream>
#include<algorithm>

using namespace std;

int main()
{
	int a1[] = { 1,23,4,5,678 };
	constexpr auto sizea1 = sizeof(a1) / sizeof(*a1);
	int a2[sizea1];
	fill_n(a2, sizea1, 0);
	for (auto a : a2)
		cout << a << ends;
	cout << endl;
	system("pause");
}