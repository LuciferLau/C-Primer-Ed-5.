#include<iostream>
#include<algorithm>
#include<vector>
#include<string>

using namespace std;

void elimDups(vector<string>&vec) {
	sort(vec.begin(), vec.end());
	auto end_it = unique(vec.begin(), vec.end());
	vec.erase(end_it, vec.cend());
}

inline bool isShorter(const string &s1, const string &s2) {
	return s1.size() < s2.size();
}

void print(vector<string>&vec) {
	cout << "vector has: ";
	for (const auto v : vec)
		cout << v << ends;
	cout << endl;
}

inline bool highfive(const string &s) {
	return s.size() > 5;
}

int main()
{
	vector<string>words{ "cemetery","several","location","ask","remove","just" };
	vector<string>vec{ "abcdef","acvdef","asd","aa","bb","abc","eghji","zzzzz" };
	print(vec);
	elimDups(vec);//�ֵ�����sortĬ��
	stable_sort(vec.begin(), vec.end(), isShorter);//�ַ�����������ʹ��ν��predicate��isShorter
	print(vec);

	cout << endl;
	print(words);
	auto end_iter = partition(words.begin(), words.end(), highfive);
	words.erase(end_iter, words.cend());
	print(words);
	system("pause");
}