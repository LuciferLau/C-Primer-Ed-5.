#include<list>
#include<iostream>
#include<string>
#include<functional>
#include<algorithm>

using namespace std;

void elimDups(list<string>&lst) {
	lst.sort();//list�汾���е�sort��ͨ�ð汾�Ľ���Ԫ�صĳɱ�̫��
	lst.unique();//list�汾���е�unique���ȼ��ڣ���
	/*auto end_iter = unique(lst.begin(), lst.end());
	lst.erase(end_iter, lst.end());*/
}

void print(list<string>&lst) {
	cout << "list:";
	for (const auto l : lst)
		cout << l << ends;
	cout << endl;
}

int main()
{
	list<string>lst{ "fox","jumps","show","the","quick","red","show","the","turtle" };
	print(lst);
	elimDups(lst);
	print(lst);
	system("pause");
}