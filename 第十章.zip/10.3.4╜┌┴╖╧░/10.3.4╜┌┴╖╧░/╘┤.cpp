#include<iostream>
#include<functional>
#include<algorithm>
#include<string>
#include<vector>

using namespace std;
using namespace std::placeholders;

inline bool check_size(const string &s) {
	if (s.size() <= 6) {
		cout << s << ends;
		return true;
	}
	else return false;
}

void print(vector<string>&vec) {
	cout << "vector:";
	for (const auto v : vec)
		cout << v << ends;
	cout << endl;
}

void f1022() {
	string s[] = { "asgsaglss" ,"asgsa","shsf","safisabiuqw" };
	vector<string>vec{ s,s + 4 };
	print(vec);
	for_each(vec.begin(), vec.end(), check_size); cout << endl;
	print(vec);
}

inline bool check_size_plus(string::size_type &len,const int &num) {
	return num > len;
}

void f1024() {
	string s = "fsahfwr";
	auto len = s.size();
	cout << "s.size()=" << len << endl;
	vector<int>vec{ 1,2,3,4,5,6,7,8,9,10 };
	auto func = bind(check_size_plus,len,_1);//ͨ��bind����
	auto it = find_if(vec.begin(), vec.end(), func);//�������������ĺ�����ν�ʣ���ͨ���������õ��˱�׼�⺯����
	cout << "vector�е�һ������string���ȵ�ֵ�ǣ�" << *it << endl;
}

//void bigger(vector<string>&vec, vector<string>::size_type sz) {
//	elimDups(vec);
//	stable_sort(vec.begin(), vec.end(), [](const string &a, const string &b) {return a.size() < b.size(); });
//	auto wc = stable_partition(vec.begin(), vec.end(), [sz](const string &s) {return s.size() >= sz; });//��partition����find_if
//	auto count = vec.cend() - wc;
//	cout << count << " " << make_plural("word", "s", count) << " �ĳ��ȴ��ڵ��� " << sz << endl;
//	for_each(wc, vec.end(), [](const string &s) {cout << s << ends; });
//	cout << endl;
//}
//
//inline bool check_size_plus(string::size_type &len, const string &s) {
//	return s.size() > len;
//}
/*α����*/
//void f1025() {
//	//��bind��check_size ����lambda
//	auto func = bind(check_size, len, _1);
//	auto wc = stable_partition(vec.begin(), vec.end(),check_size );
//}

int main()
{
	f1024();
	system("pause");
}