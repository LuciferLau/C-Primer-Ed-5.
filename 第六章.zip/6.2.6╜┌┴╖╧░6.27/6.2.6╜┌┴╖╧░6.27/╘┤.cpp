#include<iostream>
#include<initializer_list>

using namespace std;

void count_add(initializer_list<int>li) {
	int res = 0;
	for (const auto &elem : li) {
		res += elem;
	}
	cout << res;
}

int main(char agrc, char **agrv) {
	initializer_list<int>li{ 1,2,3,4,5,6,7,8,9,10,100 };
	count_add(li);
	cin.get();
	return 0;
}