#include"��ͷ.h"

int main() {
	//6.32
	int ia[10];
	for (int i = 0; i != 10; ++i) {
		get(ia, i) = i;
	}
	for (auto elem : ia)
		cout << elem << " ";
	cout << endl;

	//6.33
	vector<int>vec = { 1,2,3,4,5,6,7,8,9 };
	print(vec);

	cin.get();
	return 0;
}