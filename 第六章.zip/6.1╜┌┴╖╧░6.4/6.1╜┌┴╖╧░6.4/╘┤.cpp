#include<iostream>
#include<math.h>

using namespace std;

int jc(int num) {
	if (num <= 0) return 0;
	int res = 1;
	while (num > 1) 
		res *= num--;
	return res;
}

int jdz(int num) {
	return abs(num);//meanless
}

int main() {
	int f1 = 10;
	int f2 = -10;
	cout << f1 << " " << f2 << endl;
	int res1 = jc(f1);
	int res2 = jdz(f2);
	cout << res1 << " " << res2 << endl;
	system("pause");
	return 0;
}