#include"��ͷ.h"

int main(char agrc, char*argv[]) {
	const string s1 = "success";
	const string s2 = "faliure";
	cout << "������" << make_plural(1, s1) <<" "<< make_plural(1, s2) << endl;
	cout << "������" << make_plural(2, s1, "es") << " " << make_plural(2, s2) << endl;
	cin.get();
	return 0;
}