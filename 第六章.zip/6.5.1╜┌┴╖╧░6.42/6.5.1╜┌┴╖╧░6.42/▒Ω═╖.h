#pragma once
#include<iostream>
#include<string>

using namespace std;

typedef size_t st;

/*
prototype:
string make_plural(st ctr, const string &word, const string &ending) {
	return (ctr > 1) ? word + ending : word;
}
*/

string make_plural(st ctr, const string &word, const string &ending="s") {//��Ĭ�ϲ���
	return (ctr > 1) ? word + ending : word;
}