#include"Chapter6.h"

//����һ��CPP����
string f() {
	string s;
	return s;
}

int f2(int i) {
	return i * i;
}

int calc(int v1, int v2) {
	return v1 + v2;
}

double square(double x) {
	return x * x;
}