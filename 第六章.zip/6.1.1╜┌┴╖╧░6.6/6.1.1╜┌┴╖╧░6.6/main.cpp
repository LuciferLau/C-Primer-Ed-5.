#include<iostream>
#include"Chapter6.h"
using namespace std;

int count_times() {
	static int times = 0;
	++times;
	if (times == 1)
		return 0;
	else return times - 1;
}

int three_num_addone(int n1, int n2, int n3) {//�β�
	static int one = 1;//�ֲ���̬����one
	int tmp = n1 + n2 + n3;//�ֲ�����tmp
	return tmp + one;
}

int main() {
	int res = three_num_addone(1, 2, 3);
	cout << res << endl << endl;

	cout << count_times() << endl;
	cout << count_times() << endl;
	cout << count_times() << endl << endl;

	cout << square(3.45) << endl;//��main.cpp�е���

	system("pause");
	return 0;
}