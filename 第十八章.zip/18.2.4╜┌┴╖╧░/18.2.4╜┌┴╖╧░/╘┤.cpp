#include<iostream>

using namespace std;

namespace primerLib {
	void compute();
	void compute(const void *) {
		cout << "const void *!" << endl;
	}
}

void compute(int) {
	cout << "int!" << endl;
}
void compute(double, double = 3.4) {
	cout << "double!" << endl;
}
void compute(char *, char* = 0) {
	cout << "char *!" << endl;
}

void f()
{
	using primerLib::compute;
	compute(0);
}

int main()
{
	f();
	cin.get();
}