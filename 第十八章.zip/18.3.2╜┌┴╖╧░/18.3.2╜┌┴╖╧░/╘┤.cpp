#include<iostream>

using namespace std;

class A {
	A() = default;
};

class B :public A {
	B() = default;
};

class C :public B {
	C() = default;
};

class X {
	X() = default;
};

class D :public X, public C {
	D() = default;
};

int main()
{
	D *pd = new D;//pdָ��һ��D����ֱ�ӻ�����X��C��
	X *px = pd;
	A *pa = pd;
	B *pb = pd;
	C *pc = pd;
}