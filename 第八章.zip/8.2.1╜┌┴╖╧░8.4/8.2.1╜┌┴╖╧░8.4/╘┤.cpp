#include<iostream>
#include<sstream>
#include<fstream>
#include<string>
#include<vector>
using namespace std;

int main()
{
	vector<string>vec;
	string infile = "test.txt";
	ifstream in(infile);
	if (in) {
		string buf;
		while (getline(in, buf))
			vec.push_back(buf);
	}
	else cout << "open fail!" << endl;
	for (auto v : vec)
		cout << v << ends;
	system("pause");
}