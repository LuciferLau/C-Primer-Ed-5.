#include<iostream>
#include<sstream>
#include<fstream>
#include<string>
#include<vector>

using namespace std;

istringstream& input(istringstream &iss) {//��ϰ8.9
	string s;
	while (iss >> s)
		cout << s << endl;
	iss.clear();
	return iss;
}

int main(char argc, char **argv) {
	vector<string>vec;
	string infile = "test.txt";
	ifstream in(infile);
	if (in) {
		string buf;
		while (getline(in,buf))//��ϰ813
			vec.push_back(buf);
	}
	else cout << "��ʧ�ܣ�" << endl;
	for (auto v : vec) {
		istringstream iss(v);
		string tmp;
		while (iss >> tmp)//��ϰ8.10
			cout << tmp << ends;
	}
	system("pause");
}