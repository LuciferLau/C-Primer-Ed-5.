#include<iostream>
#include<string>
using namespace std;

istream& input(istream &is) {
	string s;
	while (is >> s)
		cout << s << endl;
	is.clear();
	return is;
}

int main() {
	input(cin);
	cout << "hi!" << endl;
	cout << "hi!" << flush;
	cout << "hi!" << ends;
	system("pause");
}