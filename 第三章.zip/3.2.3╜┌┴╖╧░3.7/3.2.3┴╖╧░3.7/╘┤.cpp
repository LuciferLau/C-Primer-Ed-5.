#include<iostream>
#include<string>

using namespace std;

int main() {
	string res = "sgfasg";
	for (char &s : res) {
		s = 'X';
	}
	cout << res;
	system("pause");
	return 0;
}