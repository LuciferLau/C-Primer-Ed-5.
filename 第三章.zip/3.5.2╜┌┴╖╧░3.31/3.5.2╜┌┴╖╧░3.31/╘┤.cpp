#include<iostream>

using namespace std;

int main(void) {
	int sz[10];
	int count = 0;
	for (auto &s: sz) {
		s = count;
		count++;
		cout << s << " ";
	}
	cin.get();
	return 0;
}