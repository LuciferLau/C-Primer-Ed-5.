#include<iostream>
using namespace std;
int main() {
	int A[10] = { 1,2,3,4,5,6,7,8,9,10 };
	int *pbeg = A;
	int *pend = A + 10;
	for (auto a : A) {
		cout << a << " ";
	}
	cout << endl;
	while (pbeg != pend) {
		*pbeg = 0;
		pbeg++;
	}
	for (auto a : A) {
		cout << a << " ";
	}
	cin.get();
	return 0;
}