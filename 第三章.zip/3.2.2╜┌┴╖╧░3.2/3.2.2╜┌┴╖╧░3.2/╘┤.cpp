#include<iostream>
#include<string>

using namespace std;

int main(void){
	string test;
	string line;
	auto count=0;
	while (cin >> test) {
		cout << test << endl;
		count++;
	}
	cout << "test input times :" << count << endl;
	while (getline(cin, line)) {
		cout << line<<endl;
	}
	
	return 0;
}