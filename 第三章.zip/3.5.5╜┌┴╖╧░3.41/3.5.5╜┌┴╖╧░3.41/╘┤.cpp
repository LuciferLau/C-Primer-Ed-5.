#include<iostream>
#include<vector>
#include<iterator>
using namespace std;

int main() {
	int a[] = { 1,2,3,4 };
	vector<int>vec(a, a + 4);
	vector<int>res(begin(a), end(a));
	int b[4] = {};
	for (auto s : vec)
		cout << s << " ";
	cout << endl;
	for (auto s : res)
		cout << s << " ";
	cout << endl;
	//��res���ݿ���������b[4]�У�
	int i = 0;
	for (auto s : res) {
		b[i] = s;
		++i;
	}
	for (auto s : b)
		cout << s << " ";
	cout << endl;
	cin.get();
	return 0;
}