#include<iostream>
#include<string>

using namespace std;

int main() {
	string res = "i'm fucking test,and fuck off,you mother fucker.";
	cout << res << endl;
	for (auto &s : res) {
		if (ispunct(s)) s = ' ';
	}
	cout << res;
	cin.get();
	return 0;
}