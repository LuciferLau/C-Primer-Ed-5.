#include<iostream>
#include<vector>
#include<iterator>
using namespace std;

bool vecsame(vector<int>&vec1, vector<int>&vec2) {
	auto beg1 = vec1.begin(), end1 = vec1.end();
	auto beg2 = vec2.begin(), end2 = vec2.end();
	for (beg1, beg2; beg1 != end1&&beg2 != end2; beg1++, beg2++) {
		if (*beg1 != *beg2){
			cout << *beg1<<"!="<<*beg2<<" vec���鲻ͬ��" << endl;
			return false;
		}		
	}
	if ((beg1 == end1 && beg2 != end2)|| (beg1 != end1 && beg2 == end2)) {
		cout << "vec���鳤�Ȳ�һ�£���ͬ��" << endl;
		return false;
	}
	cout << "vec������ͬ��" << endl;
	return true;
}

bool szsame(int a1[], int a2[],int s1,int s2) {
	if (s1 != s2) {
		cout << "���鳤�Ȳ�һ�£���ͬ��" << endl;
		return false;
	}
	int *beg1 = a1, *end1 = beg1 + s1;
	int *beg2 = a2, *end2 = beg2 + s2;
	for (beg1, beg2; beg1 != end1 && beg2 != end2; beg1++, beg2++) {
		if (*beg1 != *beg2) {
			cout << *beg1 << "!=" << *beg2 << " ���鲻ͬ��" << endl;
			return false;
		}
	}
	cout << "������ͬ��" << endl;
	return true;
}

int main() {
	vector<int>t1{ 1,2,3,4,5 };
	vector<int>t2{ 1,2,3,4 };
	vector<int>t3{ 1,2,3,4,5 };
	vecsame(t1, t2);//��ͬ
	vecsame(t1, t3);//ͬ

	int t4[] = { 1,2,3,4,5 };
	int t5[] = { 1,2,3,4,5 };
	int t6[] = { 1,2,3,4 };
	szsame(t4, t5,5,5);//ͬ
	szsame(t5, t6,5,4);//��ͬ

	cin.get();
	return 0;
}