#include<iostream>
#include<cstring>

using namespace std;

int main() {
	const char a[] = "lau";
	const char b[] = "kaho";
	char res[100] = { };
	strcpy_s(res, a);
	strcat_s(res, b);
	//��Ҫ_CRT_SECURE_NO_WARNINGS��������strcat/strcpy
	cout << res;
	cin.get();
	return 0;
}