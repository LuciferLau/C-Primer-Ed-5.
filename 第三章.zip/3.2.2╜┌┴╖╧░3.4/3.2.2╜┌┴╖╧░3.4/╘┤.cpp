#include<iostream>
#include<string>

using namespace std;
void bigger(string &s1, string &s2) {
	cout << "The follow one is bigger!" << endl;
	if (s1 > s2)cout << s1 << endl;
	if (s1 == s2)cout << "equal!" << endl;
	if (s1 < s2)cout << s2 << endl;
}

void longer(string &s1, string &s2) {
	auto l1 = s1.size();
	auto l2 = s2.size();
	cout << "The follow one is longer!" << endl;
	if (l1 > l2)cout << s1 << endl;
	if (l1 == l2)cout << "equal!" << endl;
	if (l1 < l2)cout << s2 << endl;
}

int main() {
	string s1, s2;
	cin >> s1 >> s2;
	bigger(s1, s2);
	longer(s1, s2);
	system("pause");
	return 0;
}