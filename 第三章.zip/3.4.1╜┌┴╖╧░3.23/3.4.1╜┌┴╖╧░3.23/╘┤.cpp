#include<iostream>
#include<vector>

using namespace std;

int main() {
	vector<int>vec{ 1,2,3,4,5,6,7,8,9,10 };
	cout << "before:" << endl;
	for (auto v : vec)
		cout << v << " ";
	cout << endl;
	for (auto it = vec.begin(); it != vec.end(); ++it) 
		*it *= 2;
	cout << "after:" << endl;
	for (auto v : vec)
		cout << v << " ";
	cout << endl;
	cin.get();
	return 0;
}