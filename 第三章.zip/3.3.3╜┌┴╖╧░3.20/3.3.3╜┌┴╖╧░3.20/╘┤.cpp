#include<iostream>
#include<vector>

using namespace std;

void BeginToEnd(vector<int>&vec) {
	if (vec.begin() == vec.end()) return;
	auto len = vec.size();
	for (auto i = 0; i + 1<len; i = i + 2)
		cout << vec[i] + vec[i + 1] << endl;
	auto end = vec.end() - 1;
	if (len % 2 == 1)
		cout << *end << endl;
}

void BeginEndToMid(vector<int>&vec) {	
	if (vec.begin() == vec.end()) return;
	vector<int>::iterator start = vec.begin(), end = vec.end()-1;
	auto len = vec.size();
	for (start,end;start!=end&&start<end;++start,--end)
		cout << *start + *end << endl;
	if (len % 2 == 1)
		cout << *(start) << endl;//cout << *(end) << endl;һ��
}


int main() {
	vector<int>vec;
	int num;
	while (cin >> num)
		vec.push_back(num);
	cout << "��ͷ��ʼ������ӣ�" << endl;
	BeginToEnd(vec);
	cout << "ͷ��β�ֱ���ӣ�ָ��ֱ�ǰ�������ˣ�" << endl;
	BeginEndToMid(vec);
	cin.clear();
	cin.get();
	return 0;
}