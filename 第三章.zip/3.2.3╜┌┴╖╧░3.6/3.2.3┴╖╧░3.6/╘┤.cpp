#include<iostream>
#include<string>

using namespace std;

int main() {
	string res = "qwgfasg";
	for (auto &s : res)//auto s��ʧЧ������&s��
		s = 'X';
	cout << res;
	system("pause");
	return 0;
}