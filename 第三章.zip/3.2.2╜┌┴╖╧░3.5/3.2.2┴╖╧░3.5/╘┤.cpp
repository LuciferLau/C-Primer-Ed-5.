#include<iostream>
#include<string>

using namespace std;

int main() {
	string ss, res;
	while (cin >> ss) {
		if (ss == "end")
			break;
		res =res + ss+' ';//res += ss;
	}
	cout << res;
	system("pause");
	return 0;
}