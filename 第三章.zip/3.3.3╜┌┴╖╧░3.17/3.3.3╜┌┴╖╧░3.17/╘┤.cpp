#include<iostream>
#include<vector>
#include<string>
#include<cctype>
using namespace std;

int main() {
	string s;
	vector<string>text;
	while (cin >> s)
		text.push_back(s);
	cout << "now wo have:" << endl;
	for (auto x : text)
		cout << x << endl;

	for (auto &x : text)
		for (auto &y : x)
			if (islower(y))
				y=toupper(y);
		
	cout << "then wo have:" << endl;
	for (auto x : text)
		cout << x << endl;
	cin.clear();
	cin.get();
	return 0;
}