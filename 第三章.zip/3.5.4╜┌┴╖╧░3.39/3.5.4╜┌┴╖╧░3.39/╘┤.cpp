#include<iostream>
#include<string>
#include<cstring>

using namespace std;

void str(const string &s1, const string &s2) {
	if (s1 != s2)
		cout << "string��ͬ��" << endl;
	else
		cout << "string��ͬ��" << endl;
}

void cstr(const char s1[], const char s2[]) {
	if(strcmp(s1,s2)!=0)
		cout << "cstr��ͬ��" << endl;
	else
		cout << "cstr��ͬ��" << endl;
}

int main() {
	const string a = "leo";
	const string b = "lucifer";
	const string f = "leo";
	str(a, b);
	str(a, f);

	const char c[] = { 'lau','\0' };
	const char d[] = { 'ka','ho','\0' };
	const char e[] = { 'lau','\0' };	
	cstr(c, d);
	cstr(c, e);

	cin.get();
	return 0;
}