#include"EMPLOYEE.h"

using namespace std;

void f1() {
	Employee a("Leo", "���ݴ�ѧ", 1);
	cout << a << endl;
	Employee &&b = std::move(a);
	cout << b << endl;
}

void f2() {
	Employee a;
	cin >> a;
	cout << a << endl;
}

void f3() {
	Employee a("Leo", "���ݴ�ѧ", 1);
	Employee b("Lau", "���ݴ�ѧ", 2);
	Employee c("Leo", "���ݴ�ѧ", 1);
	if (a == b)
		cout << "true!" << endl;
	else cout << "false!" << endl;
	if (a == c)
		cout << "true!" << endl;
	else cout << "false!" << endl;
}

void f4() {
	Employee a("Leo", "���ݴ�ѧ", 1);
	Employee b("Lau", "���ݴ�ѧ", 2);
	if (a > b)
		cout << "a > b true!" << endl;
	else cout << "a > b false!" << endl;
	if (a < b)
		cout << "a < b true!" << endl;
	else cout << "a < b false!" << endl;
}

int main()
{
	f4();
	system("pause");
	return 0;
}