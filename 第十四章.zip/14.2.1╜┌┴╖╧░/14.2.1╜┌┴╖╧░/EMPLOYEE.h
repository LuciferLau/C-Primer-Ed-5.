#pragma once
#include<iostream>
#include<utility>
#include<string>

class Employee {
	friend Employee operator+=(const Employee &, const Employee &);
	friend std::istream& operator>>(std::istream&os, Employee &);
	friend std::ostream& operator<<(std::ostream&, const Employee &);
	friend bool operator==(const Employee&, const Employee&);
	friend bool operator!=(const Employee&, const Employee&);
	friend bool operator<(const Employee&, const Employee&);
	friend bool operator>(const Employee&, const Employee&);
public:
	~Employee() { free(); }
	Employee() = default;
	Employee(std::string n, std::string a, int i) :name(n), address(a), id(i) {}
	Employee(const Employee&e) :name(e.name), address(e.address), id(e.id) {}
	Employee& operator=(const Employee&e) {
		if (*this != e) {//��ֹ�Ը�ֵ
			free();
			name = e.name;
			address = e.address;
			id = e.id;
		}
		return *this;
	}
	Employee(Employee&&e) noexcept :name(e.name), address(e.address), id(e.id) { e.name = e.address = nullptr; e.id = 0; }
	Employee& operator=(Employee&&e)noexcept {
		if (*this != e) {//��ֹ�Ը�ֵ
			free();
			name = e.name;
			address = e.address;
			id = e.id;
			e.name = e.address = nullptr;
			e.id = 0;
		}
		return *this;
	}
	void free() {
		if (id != 0) {
			std::cout << "���ͷ� " << name << " ��..." << std::endl;
			name = address = "";
			id = 0;
		}
		std::cout << " �ͷ���ɣ�" << std::endl;
	}
private:
	std::string name;
	std::string address;
	int id;
};

bool operator!=(const Employee&e1, const Employee&e2) {
	if (!(e1==e2))
		return true;
	return false;
}

bool operator==(const Employee&e1, const Employee&e2) {
	if (e1.id == e2.id &&e1.name == e2.name&&e1.address == e2.address)
		return true;
	return false;
}

std::ostream& operator<<(std::ostream&os, const Employee &e) {//��ϰ14.5
	os << e.id << std::ends << e.name << std::ends << e.address << std::ends;
	return os;
}

std::istream& operator>>(std::istream&is, Employee &e) {//��ϰ14.11
	std::cout << "�������ţ�";
	is >> e.id;
	std::cout << "������������";
	is >> e.name;
	std::cout << "�������ַ��";
	is >> e.address;
	if (is)
		return is;
	else e = Employee();
	return is;
}

Employee operator+=(const Employee &lz, const Employee &rz) {
	//����Ҫ
	return lz;
}

Employee operator+(const Employee &lz, const Employee &rz) {
	//δ����
	Employee tmp = lz;
	tmp += rz;
	return tmp;
}

bool operator<(const Employee&l, const Employee&r) {
	if (l.id < r.id)
		return true;
	else return false;
}

bool operator>(const Employee&l, const Employee&r) {
	if (l.id > r.id)
		return true;
	else return false;
}