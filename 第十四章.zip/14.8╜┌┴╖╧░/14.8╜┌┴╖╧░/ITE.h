#pragma once
#include<iostream>

class If_Then_Else {
public:
	int operator()(int a, int b, int c)const {
		return a >= 100 ? b : c;
	}
};