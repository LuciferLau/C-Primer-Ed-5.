#include"ITE.h"
#include"GS.h"
#include"EQ.h"
#include<vector>
#include<algorithm>

using namespace std;

void f1434() {
	If_Then_Else fuc;
	int a = 100, b = 20, c = 50, d;
	d = fuc(a, b, c);
	cout << d << endl;
}

void f1435() {
	Getstring fuc;
	string a;
	a = fuc();
	cout << a << endl;
}

void f1436() {
	Getstring getstr;
	vector<string>vec;
	string tmp;
	while ((tmp = getstr()) != "") {
		vec.push_back(tmp);
	}
	cout << "������ɣ�" << endl;
	for (auto v : vec)
		cout << v << ends;
	cout << endl;
}

void preb(int &a) {
	EQ fuc;
	if (fuc(a))
		a = 10;//��2ȫ���滻Ϊ10
}

void f1437() {
	vector<int>vec{ 1,2,2,4,5,9,10,1,2,3,4,5,6,7,8,9 };
	for (auto v : vec)
		cout << v << ends;
	cout << endl;
	for_each(vec.begin(), vec.end(),preb);
	for (auto v : vec)
		cout << v << ends;
	cout << endl;
}

int main()
{
	f1437();
	system("pause");
}