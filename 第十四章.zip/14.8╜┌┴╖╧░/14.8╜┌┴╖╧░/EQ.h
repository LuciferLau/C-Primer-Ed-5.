#pragma once

class EQ {
public:
	bool operator()(int a) {
		return a == b;
	}
private:
	static int b;
};

int EQ::b = 2;