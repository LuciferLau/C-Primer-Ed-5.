#pragma once
#include<string>
#include<iostream>

class Getstring {
public:
	Getstring(std::istream &in = std::cin, std::string s = "") :is(in), str(s) {}//Ĭ��Ϊcin�Ϳ��ַ���
	std::string operator()()const {
		std::string s;
		if (std::getline(is, s))
			return s;
		else 
			return str;
	}
private:
	std::istream &is;
	std::string str;
};