#pragma once
#include<iostream>
#include<string>

class CheckStr {
public:
	std::size_t operator()(const std::string &s) {
		return s.size();
	}
};
