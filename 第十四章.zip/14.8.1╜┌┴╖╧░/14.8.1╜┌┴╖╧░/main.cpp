#include"CHECKSTR.h"
#include<fstream>
#include<map>
#include<vector>
#include<algorithm>
using namespace std;

void f1438() {
	map<int, int>countmap;
	CheckStr func;
	ifstream in("text.txt");
	string s;
	while (in >> s) {
		switch (func(s)) {
		case 1:
			++countmap[1];
			break;
		case 2:
			++countmap[2];
			break;
		case 3:
			++countmap[3];
			break;
		case 4:
			++countmap[4];
			break;
		case 5:
			++countmap[5];
			break;
		case 6:
			++countmap[6];
			break;
		case 7:
			++countmap[7];
			break;
		case 8:
			++countmap[8];
			break;
		case 9:
			++countmap[9];
			break;
		case 10:
			++countmap[10];
			break;
		default:
			break;
		}
	}
	for (auto elem : countmap)
		cout << "���ʳ���Ϊ" << elem.first << "�ĸ����У�" << elem.second << "����" << endl;
}

void f1439() {
	vector < int> vec(2, 0);
	CheckStr func;
	ifstream in("text.txt");
	string s;
	while (in >> s) {
		if (func(s) >= 1 && func(s) <= 9)
			++vec[0];
		else if (func(s) >= 10)
			++vec[1];
	}
	cout << "���ʳ���Ϊ1~9�ĸ����У�" << vec[0] << "����" << endl;
	cout << "���ʳ���>=10�ĸ����У�" << vec[1] << "����" << endl;
}

class BiggerOne {
public:
	bool operator()(const string &a, const string &b) const {
		return a.size() > b.size();
	}
};

class BJ {
	size_t sz;
public:
	BJ(size_t n) :sz(n) {}//���βζ�Ӧ�ղ��ı���
	bool operator()(const string &s) const {
		return s.size() >= sz;
	}
};

class SC {
public:
	SC(ostream &o = cout, string s = "") :os(o), str(s) {}
	void operator()(const string& s)const {
		os << s << endl;
	}
private:
	ostream & os;
	string str;
};

void biggie(vector<string> &words, vector<string>::size_type sz) {//�ú��������滻lambda
	stable_sort(words.begin(), words.end(), BiggerOne());
	auto wc = find_if(words.begin(), words.end(), BJ(sz));
	auto count = words.end() - wc;
	for_each(wc, words.end(), SC());
}

int main()
{
	system("pause");
}