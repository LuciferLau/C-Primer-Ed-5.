#include<iostream>
#include<vector>
#include<string>
using namespace std;

void print(vector<int>&vec) {
	cout << "��ǰvector.size�ǣ�" << vec.size() << endl;
	cout << "��ǰvector.capacity�ǣ�" << vec.capacity() << endl;
	cout << endl;
}

vector<int> func(int num) {
	vector<int>vec;
	vec.reserve(1024);
	int begin = 0;
	int word = 0;
	while (begin++!=num)
		vec.push_back(word);
	vec.resize(vec.size() + vec.size() / 2);
	print(vec);
	return vec;
}

int main()
{
	vector<int>vec;
	vec.reserve(1024);
	print(vec);
	func(256);//����256��int
	func(512);//����512��int
	func(1000);//����1000��int
	func(1024);//����1048��int

	system("pause");
	return 0;
}