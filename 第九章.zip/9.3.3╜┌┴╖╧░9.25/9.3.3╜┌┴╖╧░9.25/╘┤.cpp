#include<iostream>
#include<list>
#include<vector>
using namespace std;


void f926() {
	int ia[] = { 0,1,1,2,3,5,8,13,21,55,89 };
	vector<int>vec;
	list<int>ll;
	for (size_t i=0; i < sizeof(ia)/sizeof(int); ++i) {
		vec.emplace_back(ia[i]);
		ll.emplace_back(ia[i]);
	}
	for (auto it = vec.begin(); it != vec.end(); ) 
		(*it % 2 == 0) ? it = vec.erase(it) : ++it;
	for (auto it = ll.begin(); it != ll.end(); ) 
		(*it % 2 == 1) ? it = ll.erase(it) : ++it;;
	cout << "����vector:";
	for (auto v : vec)
		cout << v << ends;
	cout << endl << "ż��list:";
	for (auto l : ll)
		cout << l << ends;
	cout << endl;
}
int main()
{
	list<int>ll{ 1,2,3,4,5,6,7 };
	list<int>ll2{ 1,2,3,4,5 };
	auto elem1 = ll.begin();
	auto elem2 = --ll.end();
	auto elem3 = ll2.end();
	auto elem4 = elem3;
	cout << "elem1:" << *elem1 << endl;
	cout << "elem2:" << *elem2 << endl;
	elem1 = ll.erase(elem1, elem2);//ɾ��[elem1,elem2)������elem2�ĵ�����
	cout << "elem1:" << *elem1 << endl;
	cout << "elem2:" << *elem2 << endl;
	cout << "list:";
	for (auto l : ll)
		cout << l << ends;
	cout << endl << endl;
	ll2.erase(elem3, elem4);
	cout << "list2:";
	for (auto l : ll2)
		cout << l << ends;
	cout << endl << endl;
	f926();
	system("pause");
}