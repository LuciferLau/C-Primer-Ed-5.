#include"YearMoonDay.h"
#include<iostream>
#include<vector>
#include<string>

using namespace std;

void f950() {//��������ֵ
	vector<string>vec = { "214","23","130" };
	int res = 0;
	for (auto v : vec)
		res+=stoi(v);
	cout << res << endl;
}

void f950_() {//���㸡����ֵ֮��
	vector<string>vec = { "214.214","23.23","130.130" };
	float res = 0;
	for (auto v : vec)
		res += stof(v);
	cout << res << endl;
}

int main()
{
	string date{ "January 1,1900" };
	f950();
	f950_();
	cout << endl;
	YearMoonDay d1(date);
	
	system("pause");
}