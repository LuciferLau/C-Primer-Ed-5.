#include<iostream>  
#include<fstream>  
#include<sstream>  
#include<string>  
#include<vector>  
#include<forward_list>  
using namespace std;

void f943(string &s, string &oldVal, string &newVal)
{
	auto oldsize = oldVal.size();
	auto newsize = newVal.size();
	string::iterator sbeg = s.begin();

	for (sbeg; sbeg <= (s.end() - oldsize + 1); ++sbeg)//ʹ��insert
	{
		if ((s.substr(sbeg - s.begin(), oldsize) == oldVal)) {//substr()�����þ��ǽ�ȡstring�е�һ��  
			sbeg = s.erase(sbeg, sbeg + oldsize);//���ص������һ����ɾ����Ԫ��֮���λ��  
			s.insert(sbeg, newVal.begin(),newVal.end());
			sbeg = s.begin();
		}
	}
}


void f944(string &s, string &oldVal, string &newVal)//ʹ��replace
{
	auto oldsize = oldVal.size();
	auto newsize = newVal.size();
	for (size_t i = 0; i < s.size() - oldsize;) {
		if ((s.substr(i, oldsize) == oldVal)){//substr()�����þ��ǽ�ȡstring�е�һ��  
			s.replace(i, oldsize, newVal);
			i += (newsize - oldsize);
		}
		else
			i++;
	}
}

void f945(string &name) {//�õ�������insert��append
	int num = INT_MIN;
	string sex[2]{ "Mr. ","Ms. " };
	string qz = "", hz = "";
	cout << "choose your prefix��1��Mr.  2��Ms.  :"; cin >> num;
	switch (num)
	{
	case 1:
		qz = sex[0];
		break;
	case 2:
		qz = sex[1];
		break;
	default:
		cout << "input again , please ." << endl;
		break;
	}
	cout << "What is your Suffix name? Please input it:"; cin >> hz;
	cout << "Got it!" << endl;
	string res = name;
	res.insert(res.cbegin(), qz.cbegin(),qz.cend());
	res.append(" ");
	res.append(hz);
	cout << "Hello~" << res << endl;
}

void f946(string &name) {//��λ�úͳ��ȹ���string��ֻʹ��insert
	int num = INT_MIN;
	string sex[2]{ "Mr. ","Ms. " };
	string qz = "", hz = "";
	cout << "choose your prefix��1��Mr.  2��Ms.  :"; cin >> num;
	switch (num)
	{
	case 1:
		qz = sex[0];
		break;
	case 2:
		qz = sex[1];
		break;
	default:
		cout << "input again , please ." << endl;
		break;
	}
	cout << "What is your Suffix name? Please input it:"; cin >> hz;
	cout << "Got it!" << endl;
	string res = name;
	res.insert(res.cbegin(), qz.cbegin(), qz.cend());
	res.insert(res.cend(), hz.cbegin(), hz.cend());
	cout << "Hello~" << res << endl;
}

int main(int argc, char**argv)
{
	string s = "Sunday morning I was boring!";
	cout << "olds:" << s << endl;
	string oldVal = "morning";
	string newVal = "afternoon";
	cout << "oldVal:" << oldVal << endl;
	cout << "newval:" << newVal << endl;
	f943(s, oldVal, newVal);
	cout << "news:" << s << endl;
	string name;
	cout << "What is your name? Please input it:"; cin >> name;
	f945(name);
	f946(name);
	system("pause");
	return 0;
}