#include<iostream>
#include<vector>

using namespace std;

bool have_num(vector<int>&vec, int i) {
	for (auto v : vec) {
		if (v == i) {
			cout << "�ҵ��ˣ�" << endl;
			return true;
		}	
	}
	cout << "û�ҵ�Ŷ��" << endl;
	return false;
}

bool have_num(vector<int>::iterator &beg, vector<int>::iterator &end, int i) {
	while (beg!=end) {
		if (*beg++ == i) {
			cout << "�ҵ��ˣ�" << endl;
			return true;
		}
	}
	cout << "û�ҵ�Ŷ��" << endl;
	return false;
}

int main() {
	vector<int>vec{ 0,1,2,3,4,5 };
	vector<int>::iterator beg = vec.begin();
	vector<int>::iterator end = vec.end();
	have_num(vec, 7);
	have_num(beg, end, 5);
	system("pause");
}