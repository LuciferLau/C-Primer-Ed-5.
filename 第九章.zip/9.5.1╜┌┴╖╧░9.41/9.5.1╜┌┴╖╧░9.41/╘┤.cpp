#include<iostream>
#include<string>
#include<vector>

using namespace std;

int main()
{
	vector<const char*>v1{"abcd","bacd" ,"cabd" "dabc" };
	vector<char>v2{ 'a','b','c','d' };
	string res = "", r2 = "";
	for (auto v : v1)
		res += v;
	for (auto v : v2)
		r2 += v;
	cout << res << endl << r2 << endl;
	system("pause");
}