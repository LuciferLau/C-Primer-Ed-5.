#include<iostream>
#include<list>
#include<vector>
#include<string>

using namespace std;

int main()
{
	char ch = 'a';
	char *hc = &ch;
	cout << *hc << endl;
	list<char *>ll{ hc };
	vector<string>vec;
	vec.assign(ll.cbegin(),ll.cend());
	cout << *vec.begin();
	cin.get();
}