#include<iostream>
#include<list>
#include<deque>

using namespace std;

int main()
{
	list<deque<int>>LL;
	system("pause");
	return 0;
}