#include<iostream>
#include<string>
#include<deque>
#include<list>
#include<vector>

using namespace std;

void f918(){ //��ϰ9.18
	deque<string>dq;
	string str;
	while (cin >> str)
		dq.emplace_back(str);
	cout << "deque:" << ends;
	for (auto it = dq.cbegin(); it != dq.cend(); it++) {
		cout << *it << ends;
	}
}

void f919() {	//��ϰ9.19
	list<string>ll;
	string str;
	while (cin >> str)
		ll.push_back(str);
	cout << "list:" << ends;
	for (auto it = ll.cbegin(); it != ll.cend(); it++) {
		cout << *it << ends;
	}
}

void f920() {//��ϰ9.20
	list<int>ll{ 1,2,3,4,5,6,7,8,9 };
	deque<int>js, os;
	for (auto l : ll) {
		if (l % 2 == 0)
			os.emplace_back(l);
		else js.emplace_back(l);
	}
	cout << "����deque��";
	for (auto d : js)
		cout << d << ends;
	cout << endl << "ż��deque��";
	for (auto d : os)
		cout << d << ends;
	cout << endl;
}

void f921() {
	vector<string>vec;
	auto vbeg = vec.begin();
	string str;
	while (cin >> str)
		vbeg = vec.emplace(vbeg, str);//vbeg = vec.insert(vbeg, str);
	for (auto v : vec)
		cout << v << ends;
	cout << endl;
}

int main()
{
	f921();

	system("pause");
}