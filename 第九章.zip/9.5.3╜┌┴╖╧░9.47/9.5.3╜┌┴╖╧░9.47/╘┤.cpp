#include<iostream>
#include<string>

using namespace std;

void f9471() {//ʹ��find_first_of
	string zm{ "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ" };
	string sz{ "0123456789" };
	string  s = "ab2c3d7R4E6";
	int letter = 1;
	int digit = 1;
	string::size_type pos1 = 0;
	string::size_type pos2 = 0;

	while ((pos1 = s.find_first_of(zm, pos1)) != string::npos) {
		cout << letter++ << "�� letter is:" << s[pos1] << " and it's index is: " << pos1 << endl;
		++pos1;
	}
	cout << endl;
	while ((pos2 = s.find_first_of(sz, pos2)) != string::npos) {
		cout << digit++ << "�� digit is:" << s[pos2] << " and it's index is: " << pos2 << endl;
		++pos2;
	}
}

void f9472() {//ʹ��find_first_not_of��ֻ��Ե�һ�µ�һ������
	string zm{ "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ" };
	string sz{ "0123456789" };
	string  s = "ab2c3d7R4E6";
	int letter = 1;
	int digit = 1;
	string::size_type pos1 = 0;
	string::size_type pos2 = 0;

	while ((pos1 = s.find_first_not_of(sz, pos1)) != string::npos) {
		cout << letter++ << "�� letter is:" << s[pos1] << " and it's index is: " << pos1 << endl;
		++pos1;
	}
	cout << endl;
	while ((pos2 = s.find_first_not_of(zm, pos2)) != string::npos) {
		cout << digit++ << "�� digit is:" << s[pos2] << " and it's index is: " << pos2 << endl;
		++pos2;
	}
}

int main()
{
	f9471();
	cout << endl;
	f9472();
	system("pause");
}