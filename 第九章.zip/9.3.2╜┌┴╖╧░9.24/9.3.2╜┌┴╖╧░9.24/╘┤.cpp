#include<iostream>
#include<vector>

using namespace std;

int main()
{
	vector<int>vec{ 1,2,3,4 };
	cout << vec.at(0) << endl;
	cout << vec.front() << endl;
	cout << *vec.cbegin() << endl;
	cout << vec[0] << endl;
	cin.get();
}