#include"��ͷ.h"

using namespace std;

int main()
{
	//16.62:
	unordered_multiset<Sales_data>myset;
	myset.emplace("Chinese", 10, 0.75);
	myset.emplace("English", 15, 0.7);
	for (const auto&elem : myset) 
		cout << "�鱾��" << elem.isbn() << " �� hash�ǣ�" << std::hash<Sales_data>()(elem) << endl;
	//16.63:
	vector<int>ivec{ 1,2,3,4,5,6,1,1,1 };
	vector<double>dvec{ 3.14,2.2,3.3,1.24,4.231 };
	vector<string>svec{ "hi","leo","hello","yes","hi" };
	cout << counter(ivec, 1) << endl;
	cout << counter(dvec, 3.147) << endl;
	cout << counter(svec, "hi") << endl;
	//16.64:
	const char sz[] = { 'a','b','c','d','\0' };
	const char *pa = &sz[0], *pb = &sz[1], *pc = &sz[2], *pd = &sz[3];
	vector<const char*>cvec{ pa,pb,pc,pd };
	cout << counter(cvec, "a") << endl;
	//16.65:
	char c[] = { 'a','\0' };
	char *pcc = &c[0];
	cout << debug_rep(pcc) << endl;
	cout << debug_rep(pa) << endl;
	cout << debug_rep(pb) << endl;
	cout << debug_rep(pc) << endl;
	cout << debug_rep(pd) << endl;
	cin.get();
}