#include<iostream>
#include<vector>
#include<string>
#include<list>
#include<initializer_list>

using namespace std;

template<typename T>
ostream& my_print(ostream& os, const T& t) {
	return os << t;
}

template<typename T,typename ...Args>
ostream& my_print(ostream& os, const T& t,const Args& ...rest) {
	os << t << " , ";
	return my_print(os, rest...);
}

int main() 
{
	string s = "world";
	vector<int>vec(1, 1);
	int i = 1;
	my_print(cout, "hi", s,i);
	cin.get();
}