#include<iostream>
#include<string>
#include<memory>

using namespace std;

template<typename T, typename... Args>
inline shared_ptr<T> my_make_shared(Args&&... args) {
	cout << "using my_make ! " << endl;
	shared_ptr<T>ptr(new T(std::forward<Args>(args)...));
	//����ָ������Ĺ��캯����explicit�ģ�����ֱ�ӳ�ʼ�����ã�����
	return ptr;
}

template<typename T, typename... Args>
inline shared_ptr<T> my_make_shared2(Args&&... args) {
	cout << "using my_make2 ! " << endl;
	return shared_ptr<T>(new T(std::forward<Args>(args)...));
}

int main()
{
	auto a = my_make_shared<int>(42);
	auto b = my_make_shared<string>(5,'a');
	auto c = my_make_shared2<string>(2,'b');
	cout << *a << " " << a.use_count()<< endl;
	cout << *b << " " << b.use_count()<< endl;
	cout << *c << " " << c.use_count()<< endl;
	cin.get();
}