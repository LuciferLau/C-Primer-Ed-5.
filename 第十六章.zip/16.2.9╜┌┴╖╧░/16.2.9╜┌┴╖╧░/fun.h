#pragma once
#include<utility>

template<typename F, typename T1, typename T2>
void fanzuan(F f, T1&& a, T2&& b) {
	f(std::forward<T2>(b), std::forward<T1>(a));
}

template<typename F, typename T1, typename T2>
void fanzuan2(F f, T1&& a, T2&& b) {
	f(b,a);
}