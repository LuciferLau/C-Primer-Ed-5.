#pragma once
#include<iostream>
#include<string>

//16.2
template<typename T>
bool compare(const T &lhs, const T &rhs) {
	return lhs < rhs;
}

//16.3
class Sales_data
{
public:
	Sales_data() = default;
	virtual ~Sales_data() = default;
	Sales_data(std::string name, double q) :isbn(name), price(q) {}
	Sales_data(const Sales_data&s){
		isbn = s.isbn;
		price = s.price;
	}
	Sales_data& operator=(const Sales_data&s) {
		if (*this == s)
			return *this;
		isbn = s.isbn;
		price = s.price;
	}
	bool operator==(const Sales_data&s) {
		if (isbn == s.isbn&&price == s.price)
			return true;
		return false;
	}
	bool operator<(const Sales_data&s) {
		std::cout << "using Sales_data's operator < ." << std::endl;
		if (price < s.price)
			return true;
		return false;
	}
	std::string name() { return isbn; }
private:
	std::string isbn = "";
	double price = 0.0;
};

//16.4
template<typename R,typename T>
R my_find(const R &beg,const R &end,const T &val) {
	for (auto it = beg; it != end; ++it) {
		if (*it == val)
			return it;
	}
	return end;
}

//16.5
template<typename T>
void print(const T &arr) {
	for (auto elem : arr)
		std::cout << elem << std::ends;
	std::cout << std::endl;
}

//16.6
template<typename T,unsigned N>
const T* my_begin(const T (&arr)[N])  {
	return arr;
}

template<typename T, unsigned N>
const T* my_end(const T(&arr)[N])  {
	return arr + N;
}

//16.7
template<typename T, unsigned N> constexpr
 size_t my_size(const T(&arr)[N]) {
	return N;
}