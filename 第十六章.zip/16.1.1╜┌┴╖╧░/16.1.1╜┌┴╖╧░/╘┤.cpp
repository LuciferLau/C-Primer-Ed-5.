#include"ģ��.h"
#include<vector>
#include<list>
using namespace std;

void f1() {
	int a = 1, b = 2;
	if (compare(a, b))
		cout << "true" << endl;
	else cout << "false" << endl;
	if (compare(b,a))
		cout << "true" << endl;
	else cout << "false" << endl;
}

void f2() {
	Sales_data a("���������������ɵġ�", 100);
	Sales_data b("������ŷ������Ҷ��", 70);
	cout << a.name() << endl;
	cout << b.name() << endl;
	//compare(a, b);
}

void f3() {
	vector<int>vec{ 1,2,3,4,5 };
	list<string>lst{ "alpha","beta","city","destination","evolution" };
	auto vit = my_find(vec.cbegin(), vec.cend(), 10);
	if (vit != vec.cend())
		cout << "vector find it !" << endl;
	else cout<<"vector couldn't fint it !" << endl;

	auto lit = my_find(lst.cbegin(), lst.cend(),"alpha");
	if (lit != lst.cend())
		cout << "list find it !" << endl;
	else cout << "list couldn't fint it !" << endl;
}

void f4() {
	string a1[10] = { "alpha","beta","city","destination","evolution" };
	char a2[10] = { 'a','b','c','d','e' };
	int a3[10] = { 1,2,3,4,5 };
	print(a1);
	print(a2);
	print(a3);  
}

void f5() {
	string a[5] = { "alpha","beta","city","destination","evolution" };
	auto beg = my_begin(a);
	cout << *beg << endl;
	auto end = my_end(a);
//	cout << *(end) << endl;  errorβ��ָ��
	cout << *(--end) << endl;
}

void f6() {
	string a1[10];
	char a2[20];
	int a3[30];
	cout << my_size(a1) << endl;
	cout << my_size(a2) << endl;
	cout << my_size(a3) << endl;
}

int main()
{
	f6();
	system("pause");
}