#include<iostream>
#include<string>

using namespace std;

template<typename T>
std::string debug_rep(const T& s) {
	std::cout << "const T& version." << std::endl;
	return s.str();
}

template<typename T>
std::string debug_rep(T* p) {
	std::cout << "T* version." << std::endl;
	return p->c_str();
}

//����Ҫ��������Ȼdebug_rep(char *p)��(const char *p)�汾��ʹ�� debug_rep(const char &p) 
std::string debug_rep(const std::string &p) {
	std::cout << "const std::string &p version." << std::endl;
	return p.c_str();
}

std::string debug_rep(const char *p) {
	std::cout << "const char *p version." << std::endl;
	return debug_rep(std::string(p));
}

std::string debug_rep(char *p) {
	std::cout << "char *p version." << std::endl;
	return debug_rep(std::string(p));
}

template<typename T>
ostream& my_print(ostream& os, const T& t) {
	return os << t;
}

template<typename T, typename ...Args>
ostream& my_print(ostream& os, const T& t, const Args& ...rest) {
	os << t << " , ";
	return my_print(os, rest...);
}

template<typename ... args>
ostream& errorMsg(ostream&os,const args& ...rest) {
	return my_print(os, debug_rep(rest)...);
}

int main()
{
	string a = "aaa";
	string b = "bbb";
	char c[] = "ccc";
	const char d[] = "ddd";
	errorMsg(cerr, a, b, c, d);
	cin.get();
}