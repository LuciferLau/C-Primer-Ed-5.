#include"PTR.h"
#include<string>
using namespace std;

void sp() {
	auto del = [](string *p) {cout << "using custom del !" << endl; delete p; };
	string *p = new string("I'm test text.");
	auto a = my_shared<string>(p);
	auto b = my_shared<string>(new string("bbb"));
	auto c = my_shared<string>(new string("ccc"), std::default_delete<string>());
	auto d = my_shared<string>(new string("ddd"), del);
	cout << *a << endl;
	cout << "a.use_count(): "<<a.use_count() << endl;
	cout << "Is a.unique()? ";
	if (a.unique())
		cout << "true" << endl;
	else cout << "false" << endl;
	cout << *b << endl;
	cout <<  *c << endl;
	cout <<  *d << endl;
}

void up() {
	string *p = new string("I'm test text.");
	auto a = my_unique<string>(p);
	auto b = std::move(a);
	auto c = a;
}

int main()
{
	sp();
	system("pause");
}