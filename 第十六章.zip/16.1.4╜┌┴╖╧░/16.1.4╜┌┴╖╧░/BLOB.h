#pragma once
#include<iostream>
#include<memory>
#include<vector>
#include<string>
#include<initializer_list>
template<typename T>class Blob {
public:
	typedef T value_type;
	typedef typename std::vector<T>::size_type stype;
	//����
	Blob() = default;
	Blob(std::initializer_list<T>il) :data(std::make_shared<std::vector<T>>(il)) {}
	template<typename T>Blob(T beg, T end) : data(make_shared < std::vector<T>(beg, end)) {}
	//Ԫ�ظ�����ѯ
	stype size() const { return data->size(); }
	bool empty()const { return data->empty(); }
	//Ԫ�ز���
	void push_back(const T&t) { data->push_back(t); }//�����汾
	void push_back(T &&t) { data->push_back(std::move(t)); }//�ƶ��汾
	void pop_back() { data->pop_back(); }
	//Ԫ�ط���
	T& back() { return data->back(); }
	T& operator[](stype i) { return data[i]; }

private:
	std::shared_ptr<std::vector<T>> data;
	void check(stype i, const std::string &msg) const;
};

template<typename T>//��ģ���ⶨ���Ա������Ҫ����ģ�����Ͳ���
void Blob<T>::check(stype i, const std::string &msg) const {
	if (i >= data->size())
		throw std::out_of_range(msg);
}

