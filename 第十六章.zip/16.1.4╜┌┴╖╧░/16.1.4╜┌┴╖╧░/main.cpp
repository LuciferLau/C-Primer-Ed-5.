#include"DEBUGDELETE.h"
#include"BLOB.h"
#include<list>

using namespace std;

int main()
{
	DebugDelete d;
	int* ia = new int(5);
	cout << *ia << endl;
	d(ia);
	cout << *ia << endl;
	system("pause");
}