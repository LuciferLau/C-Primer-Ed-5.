#pragma once
#include<iostream>
#include<string>

template<typename T>
std::string debug_rep(const T& s) {
	std::cout << "const T& version." << std::endl;
	return s.str();
}

template<typename T>
std::string debug_rep(T* p) {
	std::cout << "T* version." << std::endl;
	return p->c_str();
}

//����Ҫ��������Ȼdebug_rep(char *p)��(const char *p)�汾��ʹ�� debug_rep(const char &p) 
std::string debug_rep(const std::string &p) {
	std::cout << "const std::string &p version." << std::endl;
	return p.c_str();
}

std::string debug_rep(const char *p) {
	std::cout << "const char *p version." << std::endl;
	return debug_rep(std::string(p));
}

std::string debug_rep(char *p) {
	std::cout << "char *p version." << std::endl;
	return debug_rep(std::string(p));
}

template<typename T>
void f(T a) {
	std::cout << "f(T) version." << std::endl;
	std::cout << a << std::endl;
}

template<typename T>
void f(const T* a) {
	std::cout << "f(const T*) version." << std::endl;
	std::cout << *a << std::endl;
}

template<typename T>
void g(T a) {
	std::cout << "g(T) version." << std::endl;
	std::cout << a << std::endl;
}

template<typename T>
void g(T* a) {
	std::cout << "g(T*) version." << std::endl;
	std::cout << *a << std::endl;
}