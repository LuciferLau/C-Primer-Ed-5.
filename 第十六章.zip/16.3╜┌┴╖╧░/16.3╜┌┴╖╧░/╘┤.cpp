#include"DB.h"

using namespace std;

void f1648() {
	char a[] = "aaa";
	const char b[] = "bbb";
	string c("ccc");
	string tmp = "ddd";
	string *d = &tmp;
	cout << debug_rep(a) << endl;
	cout << debug_rep(b) << endl;
	cout << debug_rep(c) << endl;
	cout << debug_rep(d) << endl;
}

void f1649() {
	int i = 53, *p = &i;
	const int ci = 0, *p2 = &ci;
	g(42);
	g(p);
	g(ci);
	g(p2);

	f(42);
	f(p);
	f(ci);
	f(p2);
}

int main()
{
	f1649();
	system("pause");
}