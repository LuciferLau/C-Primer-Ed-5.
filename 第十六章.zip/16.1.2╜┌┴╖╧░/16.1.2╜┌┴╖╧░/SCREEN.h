#pragma once
#include<iostream>
#include<string>

template<typename T, unsigned S>class Screen {
public:
	Screen() = default;
	Screen(S ht, S wd, char c) :height(ht), width(wd), contents(ht*wd, c) {}
	char get()const {
		return contents[cursor];
	}
	inline char get(S r, S c);
	Screen& move(S r, S c);
private:
	S cursor = 0;
	S height = 0, wideh = 0;
	std::string contents;
};

template<typename T, unsigned S>
char Screen<T, S>::get(S r, S c) {
	S row = r * width;
	return contents[row + c];
}

template<typename T, unsigned S>
inline Screen& Screen<T, S>::move(S r, S c) {
	S row = r * width;
	cursor = row + c;
	return *this;
}