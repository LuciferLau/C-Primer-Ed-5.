#include"SUM.h"
#include<iostream>

using namespace std;

int main()
{
	long a = 12121092, b = 816228;
	auto c = my_sum(a, b);
	cout << c << endl;
	system("pause");
}