#pragma once
#include<type_traits>

template<typename T>
auto my_sum(const T& v1,const T& v2)->decltype(v1+v2)
{
	return v1 + v2;
}