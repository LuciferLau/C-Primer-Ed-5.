#include"DAYIN.h"
#include<vector>
#include<list>

using namespace std;

int main()
{
	vector<int>vec{ 1,2,3,4,5 };
	list<int>lst{ 1,2,3,4,5 ,6};
	rq_print(vec);
	//rq_print(lst); list���±���� ���Բ���
	rq_print2(vec);
	rq_print2(lst);
	system("pause");
}