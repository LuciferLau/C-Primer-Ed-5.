#include "Account.h"

int main() {
	Account a("Leo", 18888);
	Account b("john", 3);
	Account::print(a);
	Account::print(b);
	std::cout << "�趨�µ����ʣ�";
	double URrate;
	while (std::cin >> URrate)
		Account::rate(URrate);
	std::cout << "�޸���ɣ�" << std::endl << std::endl;
	a.caculate();
	b.caculate();
	Account::print(a);
	Account::print(b);

	system("pause");
	return 0;
}