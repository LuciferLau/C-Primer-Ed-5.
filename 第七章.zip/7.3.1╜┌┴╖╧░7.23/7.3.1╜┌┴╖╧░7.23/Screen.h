#pragma once
#include<iostream>
#include<string>
#include<vector>

using namespace std;

class Screen {
	friend class Window_mgr;
public:
	using pos = string::size_type;//typedef string::size_type pos;
	Screen() = default;//Ĭ�Ϲ��캯��
	Screen(pos ht, pos wd) :height(ht), width(wd), contents(ht*wd, ' ') {};//��ʾ��ʼ����contents��ʼ���ɿհ�
	Screen(pos ht, pos wd, char c) :height(ht), width(wd), contents(ht*wd, c) {};//��ʾ��ʼ����c��Ϊ��ʼ������Ļ������
	Screen &set(char);
	Screen &set(pos, pos, char);
	Screen &move(pos, pos);
	Screen &display(ostream &os);
private:
	pos height = 0, width = 0;
	pos cursor = 0;
	string contents;
};

inline Screen &Screen::set(char c) {
	contents[cursor] = c;
	return *this;
}

inline Screen &Screen::set(pos r, pos col, char c) {
	contents[r*width + col] = c;
	return *this;
}

Screen &Screen::move(pos r, pos col) {
	cursor = r * width + col;
	return *this;
}

Screen &Screen::display(ostream &os) {
	os << contents;
	return *this;
}

class Window_mgr {
public:
	using Screenindex = vector<Screen>::size_type;
	Window_mgr() = default;
	void clear(Screenindex);
private:
	vector<Screen>screens{ Screen(24,80,' ') };
};

void Window_mgr::clear(Screenindex i) {
	Screen &s = screens[i];
	s.contents = string(s.height*s.width, ' ');
}
