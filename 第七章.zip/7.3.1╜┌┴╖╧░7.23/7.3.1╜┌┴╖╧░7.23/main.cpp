#include"Screen.h"

int main(char argc, char **argv) {
	Screen myscr(5, 5, 'X');
	myscr.move(4, 0).set('#').display(cout);
	cout << endl;
	myscr.display(cout);
	cout << endl;
	system("pause");
	return 0;
}