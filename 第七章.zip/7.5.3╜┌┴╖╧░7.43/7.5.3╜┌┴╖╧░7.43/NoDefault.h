#pragma once
#include<iostream>

class NoDefault{
public:
	NoDefault(const int &i):data(i){}
private:
	int data;
};

class C {
public:
	C(int i=0):mem(i){}
private:
	NoDefault mem;
};

