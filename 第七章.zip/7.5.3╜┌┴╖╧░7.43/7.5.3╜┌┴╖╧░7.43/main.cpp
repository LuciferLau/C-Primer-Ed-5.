#include"NoDefault.h"

#include<vector>

int main()
{
	std::vector<C>vec(10);
}