#include"Person.h"

int main() {
	Person a;//Person() :name("None"), address("None") {};
	Person b("leo", "gzdx");//Person(string pname, string paddress) :name(pname), address(paddress) {};
	a.show();
	b.show();
	Person::show(a);
	Person::show(b);
	read(cin, a);
	a.show();
	Person c(cin);//Person(istream &is);
	c.show();
	system("pause");
}