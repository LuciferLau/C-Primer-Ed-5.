#include<iostream>

int main()
{
	int i, j;
	std::cout << "Input two number,make sure the first one bigger(use enter to input the next one):" << std::endl;
	std::cin >> i;
	std::cin >> j;
	while (i - j != 0)
	{
		std::cout << i << std::endl;
		--i;
	}
	std::cout << j << std::endl;
	system("pause");
	return 0;
}