#include<iostream>

int main()
{
	int i = 10;
	for (i; i >=0; --i)
		std::cout << i << std::endl;
	system("pause");
	return 0;
}