#include<iostream>
//ע�͵��÷�
int main()
{
	std::cout << "/*";
	std::cout << "*/";
	std::cout << /* "*/" */;
	std::cout << /* "*/" /* "/*" */;
}