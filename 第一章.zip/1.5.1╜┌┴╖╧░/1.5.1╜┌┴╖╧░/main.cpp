#include<iostream>
#include"Sales_item.h"

using namespace std;

void menu()
{
	cout << "Function List" << endl;
	cout << "1.��������ISBN��ͬ����������ǵĺ͡�" << endl;
	cout << "2.��ȡ���������ͬISBN�����ۼ�¼��������м�¼�ĺ͡�" << endl;
	cout << "choose one:";
}

int one()
{
	Sales_item book1, book2;
	cout << "Now input book1's information:" << endl;
	cin >> book1;
	cout << "Now input book2's information:" << endl;
	cin >> book2;
	if (book1.isbn() == book2.isbn())
	{
		cout << "Total is:" << endl;
		cout << book1 + book2 << endl;
		return 0;
	}
	else
	{
		cout << "ISBN unmatched!" << endl;
		return -1;
	}
}

int two()
{
	Sales_item book1, book2, book3, book4;
	cout << "Input 4 record with same ISBN." << endl;
	cout << "Now input book1's information:" << endl;
	cin >> book1;
	cout << "Now input book2's information:" << endl;
	cin >> book2;
	cout << "Now input book3's information:" << endl;
	cin >> book3;
	cout << "Now input book4's information:" << endl;
	cin >> book4;
	cout << "Total is:" << endl;
	cout << book1 + book2 + book3 + book4 << endl;
	return 0;
}

int main()
{
	int function;
	while (true)
	{
		menu();
		cin >> function;
		switch (function)
		{
		case 1:
			one();
			system("pause");
			system("cls");
			break;
		case 2:
			two();
			system("pause");
			system("cls");
			break;
		default:
			cout << "unrecognized input!" << endl;
			system("pause");
			system("cls");
			break;
		}
	}	
}