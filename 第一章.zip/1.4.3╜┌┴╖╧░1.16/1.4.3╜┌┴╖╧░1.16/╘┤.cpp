#include<iostream>

int main()
{
	int x, sum=0;
	while (std::cin >> x)
		sum += x;
	std::cout << sum << std::endl;
	system("pause");
	return 0;
}