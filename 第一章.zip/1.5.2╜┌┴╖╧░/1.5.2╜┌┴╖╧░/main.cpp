#include<iostream>
#include"Sales_item.h"

using namespace std;

int main()
{
	Sales_item book1, book2, book3, book4;
	cout << "Now input book1's information:" << endl;
	cin >> book1;
	cout << "Now input book2's information:" << endl;
	cin >> book2;
	cout << "Now input book3's information:" << endl;
	cin >> book3;
	cout << "Now input book4's information:" << endl;
	cin >> book4;
	
	system("pause");
	return 0;
}