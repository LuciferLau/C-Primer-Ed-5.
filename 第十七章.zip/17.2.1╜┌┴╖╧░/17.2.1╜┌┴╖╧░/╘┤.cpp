#include<iostream>
#include<bitset>

using namespace std;

int main()
{
	bitset<64>bitvec(32);
	cout << bitvec << endl;

	bitset<32>bv(1010101);
	cout << bv << endl;

	string bstr;
	cin >> bstr;
	bitset<8>bv2(bstr);
	cout << bv2 << endl;

	system("pause");
}