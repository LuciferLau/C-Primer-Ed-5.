#include<iostream>
#include<tuple>
#include<string>
#include<vector>

using namespace std;

int main()
{
	tuple<int, int, int>t{ 10,20,30 };
	int a = get<0>(t);
	int b = get<1>(t);
	int c = get<2>(t);
	cout << a << b << c;

	vector<string>svec;
	pair<string, int>p;
	tuple<string, vector<string>, pair<string, int>>tt{ "test",svec,p };

	cin.get();
}