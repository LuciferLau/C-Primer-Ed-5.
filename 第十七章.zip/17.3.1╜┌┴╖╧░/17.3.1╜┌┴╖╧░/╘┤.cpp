#include<iostream>
#include<regex>
#include<string>

using namespace std;

int main()
{
	string pattern("[^c]ei");
	pattern = "[[:alpha:]]*" + pattern + "[[:alpha:]]*";
	regex r(pattern);
	smatch result;
	string test_str;
	while (cin >> test_str) {
		bool status = false;
		try {
			status=regex_search(test_str, result, r);
		}
		catch (regex_error e) {
			cout << e.what() << endl << "code:" << e.code() << endl;
		}
		if(status)
			cout << result.str() << endl;
		else cout << "can not find it !" << endl;
	}
	
	system("pause");
}