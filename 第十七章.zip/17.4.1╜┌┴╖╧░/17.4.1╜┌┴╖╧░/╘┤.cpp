#include<iostream>
#include<ctime>
#include<random>

using namespace std;

void f1() {
	static default_random_engine e(time(0));
	static uniform_int_distribution<unsigned>u(0, 100);
	for (size_t i = 0; i < 100; ++i)
		cout << u(e) << ends;
	cout << endl << "done!" << endl;
}

void f2() {
	time_t myseed;
	cout << "input your seed :"; cin >> myseed;
	static default_random_engine e(myseed);
	static uniform_int_distribution<unsigned>u(0, 100);
	for (size_t i = 0; i < 100; ++i)
		cout << u(e) << ends;
	cout << endl << "done!" << endl;
}

void f3(unsigned max,unsigned min) {
	time_t myseed;
	cout << "input your seed :"; cin >> myseed;
	static default_random_engine e(myseed);
	static uniform_int_distribution<unsigned>u(max, min);
	for (size_t i = 0; i < 10; ++i)
		cout << u(e) << ends;
	cout << endl << "done!" << endl;
}

int main()
{
	f3(0,10);
	system("pause");
}